document.addEventListener("DOMContentLoaded", () => {
    const randomNumber = Math.floor(Math.random() * 100) + 1;
    const guessInput = document.getElementById("guessInput");
    const guessButton = document.getElementById("guessButton");
    const result = document.getElementById("result");

    guessButton.addEventListener("click", () => {
        const userGuess = parseInt(guessInput.value);

        if (isNaN(userGuess) || userGuess < 1 || userGuess > 100) {
            result.textContent = "1에서 100사이 숫자를 입력하세요";
            result.style.color = "red";
            return;
        }

        if (userGuess < randomNumber) {
            result.textContent = "너무 낮음";
            result.style.color = "blue";
        } else if (userGuess > randomNumber) {
            result.textContent = "너무 높음";
            result.style.color = "blue";
        } else {
            result.textContent = "정답";
            result.style.color = "green";
        }
    });
});
